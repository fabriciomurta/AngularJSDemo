﻿/* global Bridge */

"use strict";
Bridge.define('PhoneCat.PhoneListModel', {
    phones: null,
    orderProp: null
});

