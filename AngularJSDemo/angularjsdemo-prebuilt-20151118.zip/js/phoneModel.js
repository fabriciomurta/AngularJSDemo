﻿/* global Bridge */

"use strict";
Bridge.define('PhoneCat.PhoneModel', {
    age: 0,
    id: null,
    imageUrl: null,
    name: null,
    snippet: null
});

