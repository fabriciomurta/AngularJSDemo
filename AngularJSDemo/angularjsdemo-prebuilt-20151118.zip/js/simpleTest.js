﻿/* global Bridge */

"use strict";

Bridge.define('SimpleTest.TestClass');